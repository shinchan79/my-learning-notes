package com.cmcglobal.utils;

public enum RoleName {
	ROLE_MEMBER, ROLE_MANAGER, ROLE_ADMIN,ROLE_PM
}
