package com.cmcglobal.utils;

public class TestingConstant {
	public static final String MARK_OF_TEST = "mark";
	public static final String CORRECT_ANSWER_AMOUT = "correctAnswerAmout";
}
