/**
 * 
 */
/**
 * @author thanh
 *
 */
package com.cmcglobal.entity;