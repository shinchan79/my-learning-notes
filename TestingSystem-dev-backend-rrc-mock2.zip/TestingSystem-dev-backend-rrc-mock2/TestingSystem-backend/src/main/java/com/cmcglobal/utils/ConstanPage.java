package com.cmcglobal.utils;

public class ConstanPage {

	public static final String RES_API = "/api/auth";
	public static final String RES_API_SIGNIN = "/signin";
	public static final String RES_API_SIGNUP = "/signup";

}
