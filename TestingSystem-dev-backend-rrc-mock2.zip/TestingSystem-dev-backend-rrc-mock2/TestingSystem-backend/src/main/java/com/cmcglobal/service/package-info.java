/**
 * 
 */
/**
 * @author thanh
 *
 */
package com.cmcglobal.service;