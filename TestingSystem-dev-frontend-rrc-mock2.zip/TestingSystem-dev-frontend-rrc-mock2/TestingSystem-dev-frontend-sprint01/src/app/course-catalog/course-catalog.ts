export class CourseCatalog {

    categoryCourseId: number;
    categoryCourseName: string;
    description: string;
   
  }