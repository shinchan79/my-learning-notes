export class courseCatalog {
  categoryCourseId: number;
  categoryCourseName: string;
  description: string;
}
