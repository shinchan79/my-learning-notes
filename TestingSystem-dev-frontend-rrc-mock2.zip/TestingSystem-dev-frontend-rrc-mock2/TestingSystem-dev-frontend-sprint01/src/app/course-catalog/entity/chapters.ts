import { Course } from './course';

export class chapters  {
  chapterId: number;
  chapterName: string;
  course: Course;
}
