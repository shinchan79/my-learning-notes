export interface Answer {
  answerId: string;
  content: string;
  true: boolean;
  status: number;
}
