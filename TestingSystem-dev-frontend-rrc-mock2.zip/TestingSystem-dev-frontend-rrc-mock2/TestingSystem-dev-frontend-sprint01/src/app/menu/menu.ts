export class Menu {

    menuId: number;
    menuName: string;
    menuDescription: string;
    menuFunction: string;
  }