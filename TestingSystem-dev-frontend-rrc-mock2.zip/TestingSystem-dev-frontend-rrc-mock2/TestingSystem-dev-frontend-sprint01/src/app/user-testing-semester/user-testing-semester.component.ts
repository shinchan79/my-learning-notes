import { Component, OnInit } from '@angular/core';

@Component({
   selector: 'app-user-testing-semester',
   templateUrl: './user-testing-semester.component.html',
   styleUrls: ['./user-testing-semester.component.css']
})
export class UserTestingSemesterComponent implements OnInit {

   constructor() { }

   ngOnInit() {
      console.log('vao day ki thi')
   }

}
