import { Question } from './Question.interface';

export interface Exam {
   examId: string;
   title: string;
   numberOfQuestion: number;
}
