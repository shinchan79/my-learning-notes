export interface Answer {
   answerId: string;
   content: string;
}
