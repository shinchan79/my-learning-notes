import { Exam } from "./Exam.interface";

interface Test {
   testID: string;
   testName: string;
}
