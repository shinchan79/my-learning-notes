import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-semester-info',
  templateUrl: './semester-info.component.html',
  styleUrls: ['./semester-info.component.css']
})
export class SemesterInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
