export interface Category {
  categoryId: number;
  categoryName: string;
  dateCreated: Date;
  status: number;
}
