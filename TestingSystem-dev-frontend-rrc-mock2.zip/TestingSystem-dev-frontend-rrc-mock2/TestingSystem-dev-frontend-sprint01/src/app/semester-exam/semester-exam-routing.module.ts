import { NgModule } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';

const managerSemesterRouting: Routes = [

]

@NgModule({
   exports: [RouterModule]
}) export class SemesterExamRoutingModule {

}
