export interface SemesterExamCode {
   id: number;
   code: string;
   status: string;
   semesterexams:string

}

