export interface Test {
   testID: number,
   testName: string
   exam: {
      examId: number
   },
   semesterExam: {
       id: string
   }
}
