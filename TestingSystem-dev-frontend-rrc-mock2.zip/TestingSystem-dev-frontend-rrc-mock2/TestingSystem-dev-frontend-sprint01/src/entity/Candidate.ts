export interface Candidate {
   id :number,
   user: {
      userId: number
   },
   semesterExam: {
       id: string

   }
}
