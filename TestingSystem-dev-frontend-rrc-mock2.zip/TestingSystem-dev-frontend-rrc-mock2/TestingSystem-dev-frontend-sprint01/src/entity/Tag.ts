export class Tag {
  tagId: string;
  tagName: string;
  status: number;
}
