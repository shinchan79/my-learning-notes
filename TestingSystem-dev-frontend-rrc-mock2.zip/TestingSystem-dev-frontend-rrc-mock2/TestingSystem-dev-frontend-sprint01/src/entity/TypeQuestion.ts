export class TypeQuestion {
  typeId: string;
  typeName: string;
  status: number;
}
