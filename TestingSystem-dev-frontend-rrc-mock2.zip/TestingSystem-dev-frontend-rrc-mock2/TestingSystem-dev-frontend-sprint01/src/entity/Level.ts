export class Level {
  levelId: string;
  levelName: string;
  status: number;
}
